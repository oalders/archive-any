#!/usr/bin/perl -w
use strict;

use Acme::POE::Knee;

my $pony = new Acme::POE::Knee;
$pony->race();

exit;